import React, { PureComponent } from 'react';
import MainPage from '../src/08/components/main/MainPage';

class IndexDocument extends PureComponent {
  render() {
    return <MainPage />;
  }
}

export default IndexDocument;

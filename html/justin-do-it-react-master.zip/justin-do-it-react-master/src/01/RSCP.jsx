import React from 'react';
import PropTypes from 'prop-types';

const RSCP = props => {
  return (
    <div>
      
    </div>
  );
};

RSCP.propTypes = {
  
};

export default RSCP;

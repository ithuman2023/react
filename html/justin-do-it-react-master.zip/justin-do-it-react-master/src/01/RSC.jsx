import React from 'react';

const RSC = () => {
  return (
    <div>
      
    </div>
  );
};

export default RSC;

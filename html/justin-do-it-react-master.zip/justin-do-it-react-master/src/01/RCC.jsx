import React, { Component } from 'react';

class RCC extends Component {
  render() {
    var text = '따옴표';
    return <div name="name">{text}</div>;
  }
}

export default RCC;

import React, { Component } from 'react';
import PropTypes from 'prop-types';

class RCCP extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

RCCP.propTypes = {

};

export default RCCP;

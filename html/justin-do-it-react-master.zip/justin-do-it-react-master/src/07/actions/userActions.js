export const SET_USER = 'user/SET_USER';

export const setUser = user => ({
  type: SET_USER,
  payload: user,
});

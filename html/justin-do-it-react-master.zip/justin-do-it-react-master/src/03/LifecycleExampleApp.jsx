import React from 'react';
import LifecycleExample from './03/LifecycleExample';

class App extends React.Component {
  render() {
    return (
      <div>
        <div>
          <LifecycleExample />
        </div>
      </div>
    );
  }
}

export default App;

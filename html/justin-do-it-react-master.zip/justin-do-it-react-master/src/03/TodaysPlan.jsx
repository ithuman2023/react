import React from 'react';

class TodaysPlan extends React.Component {
  render() {
    return (
     <div className="message-container">
       놀러가자
     </div>
    );
  }
}

export default TodaysPlan;

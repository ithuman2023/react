import React from 'react';
import DefaultPropsComponent from './03/DefaultPropsComponent';

class App extends React.Component {
  render() {
    return (
      <div>
        <div>
          <DefaultPropsComponent />
        </div>
      </div>
    );
  }
}

export default App;
